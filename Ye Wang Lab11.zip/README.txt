Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab011

Description:
part1: commandline argument args[0] through parseInt the value is given to N

part2: generate a new array and fill it with random value from 0 to N by using for loop

Part3: a print method using for loop to print all elements consecutively

Part4: copy the array. a.length is used to create a array of the same length and for loop is used to allocate value

part5: find the min value. if smaller value appears min= that value. for loop used to check each element

part6: find the maxvalue. if larger value appears max= that value.for loop used to check each element



COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab11

FILES IN THIS LAB
--------------------------------------
Lab11.java
README.txt
OUTPUT.txt


