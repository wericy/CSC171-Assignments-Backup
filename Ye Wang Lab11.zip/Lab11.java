/*
 * Name: Ye Wang
 * CSC171 Lab10
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
public class Lab11 {
	
	
	public static void main (String []args)
	{
		String s1=args[0];    //part1 command-line argument
		int N=Integer.parseInt(s1);		
		
		int[] t=part2(6,N);  //test part2 construct random array
		part3(t);            //test part3  print the array just constructed
		part3(part4(t));     //test part4 print the copied array 
		System.out.println("min== "+part5(t));  // test part5, find the minimum of the array
		System.out.println("max== "+part6(t));  // test part6, find the maximum of the array
		
	}
	
	public static int[] part2(int a,int k)  //part2 of the lab 
	{
		int[] b= new int[a];
		for (int n=0;n<b.length;n++)  
			
			b[n]=(int)(Math.random()*(k+1));  // give each element of array b a random number from 0 to N inclusive
		return b;
	}
	
	public static void part3(int[] u)     //print all elements in the parameter array,separate them with comma
	{
		for (int x=0;x<u.length;x++)
			System.out.print(u[x]+",");
		System.out.println();
		
	}
	
	public static int[] part4(int[] a)  // deep copy the array with for loop
	{
		int[] b= new int[a.length];
		for (int n= 0;n<a.length;n++)
			b[n]=a[n];
		return b;
	}
	
	public static int part5(int[] a)  // find minimum value of the array
	{
		int min=Integer.MAX_VALUE;
		for (int n=0;n<a.length;n++){
			if (a[n]<min)
				min=a[n];
		}
		return min;
			
	}
	
	public static int part6(int[] a)  //find the maximum value of the array
	{
		int max=Integer.MIN_VALUE;
		for (int n=0;n<a.length;n++){
			if (a[n]>max)
				max=a[n];
		}
		return max;
		
	}

}
