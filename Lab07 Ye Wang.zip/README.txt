Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab08

Description:
My lab07 draws a creeper(Minecraft) and a "person" shouting "NO Creeper" at the side. To completed the picture, I used drawLine,drawOval,drawRect,setColor,setStroke,drawSting,drawArc,fillRect. the use of drawArc and setStroke may be the point that win extra point?


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab7

FILES IN THIS LAB
--------------------------------------
Lab7.java
README.txt
OUTPUT.txt