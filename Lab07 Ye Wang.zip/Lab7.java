/*
 * Name: Ye Wang
 * CSC171 Lab07
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import javax.swing.*;
import java.awt.*;

public class Lab7 {
	public static void main(String[] args){                                  //main program
		HelloPanel hp = new HelloPanel();
		JFrame frame = new JFrame();                                        //use of JFrame Class
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(hp);
		frame.setSize(600,600);
		frame.setVisible(true);
		frame.setResizable(false);                                        //lock frame size
		
		}
	}
class HelloPanel extends JPanel{                                          // use of JPanel
	public void paintComponent(Graphics g){
		super.paintComponents(g);
		Graphics2D g2= (Graphics2D) g.create();
		int width = getWidth();
		int height = getHeight();
	    g.setColor(new Color(28,171,0));{	    
	    g.fillRect(0, 0, 400,400);}
	    g.setColor(new Color(0,0,0));
	    g.fillRect(50, 100, 100, 100);
	    g.fillRect(250, 100, 100, 100);
	    g.fillRect(150, 200, 100,50);
		g.fillRect(100, 250, 200, 50);
		g.fillRect(100, 300, 50, 50);
		g.fillRect(250, 300, 50, 50);
		g2.setColor(Color.red);
		g2.setStroke(new BasicStroke(10, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));   //set line style
		g2.drawLine(0, 0,400,400);
		g2.drawLine(400,0,0,400);
		g2.setColor(Color.black);
		g2.setStroke(new BasicStroke(3, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		g2.drawOval(500,400,30,30);
		g2.drawLine(515, 430,515,480);
		g2.drawLine(515,450,480,420);
		g2.drawLine(515, 450,550,420);
		g2.drawLine(515, 480, 480, 500);
		g2.drawLine(515, 480, 530, 500);
		g2.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
		g2.drawArc(500,300, 80, 100, 150, 40);                                              //drawArc
		g2.drawRect(420,100,150,200);
		g2.setColor(new Color(102,204,255));
		g2.setFont(new Font("Arial", Font.BOLD, 20));                                      //set font style 
		g2.drawString("No Creeper!",430,150);

}}