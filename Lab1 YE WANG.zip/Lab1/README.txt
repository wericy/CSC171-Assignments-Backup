Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Ryan Puffer
Assignment Number:lab01

Description: 
This program is written according to the Lab1 instruction and plus one dialogue box to see welcome to users.

COMPILE INSTRCTIONS
--------------------------------------
javac lab1.java

RUN INSTRUCTIONS
--------------------------------------
java lab1

FILES IN THIS LAB
--------------------------------------
README.txt
lab1.java
OUTPUT.txt



