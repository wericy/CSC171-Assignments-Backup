/*
*Lab1
*
*1.0.0
*
*Copyright Notice
*
*Course CSC171 FALL 2013
*
*Assignment LAB1
*
*Author YE WANG
*
*Lab session Tuesday 4:50-6:05
*
*LabTA Ryan Puffer
*
*Last revised 09/11/2013
*
*/
package lab1;

import javax.swing.JOptionPane;

public class lab1 {                             // class definition
	public static void main(String[] args){     //main method start
	
	JOptionPane.showMessageDialog(null, "Welcome");
	
	//Part 1 
	System.out.println("This program was written by Ye Wang on September,11st,2013");
	
	//Part3
	System.out.println("These are a few of my \"favorite\" things:");
	System.out.println("Piano\nWinter\nRice");
	
	//Part 5
	System.out.printf("This program was written by %s on September,11st,2013\n","Ye Wang");
	System.out.printf("These are a few of my \"favorite\" things:");
	
	//Part 6
	System.out.printf("%s,%2$s,%3$s","Piano","Winter","Rice");
	
	}                                            //main method end 
}
