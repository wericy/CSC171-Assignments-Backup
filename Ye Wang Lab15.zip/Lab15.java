import javax.swing.JFrame;

public class Lab15{
	public static void main(String [] args){
		MainPanel qp =new MainPanel();                      //part1
		JFrame frame = new JFrame("Ball");                                               //create frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add(qp);
		frame.pack();
		frame.setVisible(true);
		MainPanel.Play("0.wav");
	}
}
