Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab015

Description:


Part1: start a new Mainpanel which defined in MainPanel class. Also create a frame using Jframe.The last statement starts the background music.

part2: this part include set the background color of the panle and activate keylistener. 

part3: the color array is defined at the beginning of public class MainPanel.The filloval is used to print a circle with a radius of 30. 

part4:The keylistener part will receive signals from user and do appropriate arithmetic to the coordinate of the circle . The repaint() at last will ensure the circle is repaint with the new coordinates.


extra part:the javax.sound.sampled is used to add a start up music to JPanel.The music is automatically activated.
refernece used for this part:  http://zhidao.baidu.com/question/143942532.html 




COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab15


NOTE:please make sure the wave file and .java files are in the same dictionary 

FILES IN THIS LAB
--------------------------------------
Lab15.java
MainPanel.java
README.txt
OUTPUT.txt
0.wav


