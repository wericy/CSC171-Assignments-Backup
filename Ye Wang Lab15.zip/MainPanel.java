
import java.awt.event.*;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import javax.swing.JPanel;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;



public class MainPanel extends JPanel   //part2
{
	
	Color [] cl={Color.blue,Color.black,Color.green,Color.gray,Color.yellow,Color.pink};  // here defines a new  array of color
	private final int width=600,height=600;
	private int x,y;//coordinates of circle
	final int interval=5;
	Color ccl=cl[0];  //set initial color to the first color in the array
	int count=0;// the counter is used in keylistenr to regularly assign color to ccl

	
	public MainPanel()
	{
		addKeyListener(new Kl());
		x=width/2;
		y=height/2;
		setPreferredSize(new Dimension(width,height));
		setFocusable(true);
		setBackground(new Color(102,204,255));
	}
	
	
	public void paintComponent(Graphics g)//part2 draw a oval at the centre of panel
	{
		super.paintComponent(g);
		g.setColor(ccl);     
		g.fillOval(x-15, y-15, 30, 30);		
	}
	
	
	private class Kl implements KeyListener   //part4
	{
		public void keyPressed(KeyEvent e)
		{
			switch(e.getKeyCode())
			{
			   case KeyEvent.VK_UP:
				   y-=interval;
				   break;
			   case KeyEvent.VK_DOWN:
				   y+=interval;
				   break;
			   case KeyEvent.VK_LEFT:
				   x-=interval;
				   break;
			   case KeyEvent.VK_RIGHT:
				   x+=interval;
				   break; 
			   case KeyEvent.VK_ENTER:
				   if (count==6)   //this counter count through 0 to 6 and assign different color to ccl.The counter will be reset to zero when it reaches the last element in the color array 
					   count=0;
				   ccl=cl[count];
				   count++;
				   		   
			}
			repaint();
			
		}
		
		public void keyTyped(KeyEvent e){}
		public void keyReleased(KeyEvent e){}
				
	}
	
	
	
	public static void Play(String fileurl)  // this extra part is used to buffer the music stream and play music
    {
     try{
            AudioInputStream ais = AudioSystem.getAudioInputStream(new File(fileurl));
            AudioFormat aif = ais.getFormat();
            SourceDataLine sdl = null;
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, aif);
             sdl = (SourceDataLine) AudioSystem.getLine(info);
          sdl.open(aif);
         sdl.start();
          int nByte = 0;
          byte[] buffer = new byte[128];
          while (nByte != -1)
          {
          nByte = ais.read(buffer, 0, 128);
          if (nByte >= 0){
          sdl.write(buffer, 0, nByte);
             }
          }
       sdl.stop();    //content of this page : http://zhidao.baidu.com/question/143942532.html is used to help complete this background music part
        }
     catch (Exception e){}
   }
	
	
	
	public static String randomUrl()//unused part. can be used to implement shuffle background music play
	{
		int a = (int) (Math.random()*3);
		String url="src/"+a+".wav";
		return url;
	}
	

	
	
	
}

