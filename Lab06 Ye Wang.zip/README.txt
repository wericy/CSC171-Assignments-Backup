Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab06

Description: 
Part1 : 
program asked two value from the user and use for loop to mutiply them together.

Part2:
Program used JPanel and drawOval to create several circle with a same center the first main method creates a jframe and activate the MainPanel method. However it's hard to find a way to alter the frame with the oval. if the entered number is too big the circle will go out of the frame.

Part3:


Part4:


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab6Part1.java

java Lab6Part2.java

FILES IN THIS LAB
--------------------------------------
README.txt
Lab6Part1.java
Lab6Part2.java

OUTPUT.txt