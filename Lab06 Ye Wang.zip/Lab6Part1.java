/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 06
*Date: 09/29
*/
import java.util.Scanner;
public class Lab6Part1 {
	
	public static void main(String [] args){
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter a speed in miles per hour");// ask for input
		double mile=scan.nextDouble();
		System.out.println("Please enter a number of hours");
		int hours=scan.nextInt();
		int count =1;
        for(int counter=1;counter<hours+1;counter++)//loop and out put

        System.out.println("After "+counter+" hour you will have gone "+counter*mile+" miles");
        
       
	}   
}

