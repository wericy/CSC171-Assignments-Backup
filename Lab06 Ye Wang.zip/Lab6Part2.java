/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 06
*Date: 09/29
*/
import javax.swing.*;
import java.awt.*;
public class Lab6Part2 {
	public static void main(String [] args){
		MainPanel qp =new MainPanel();
		JFrame frame = new JFrame();//create frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(qp);
		frame.setSize(400,400);
		frame.setVisible(true);
	}
}
	
class MainPanel extends JPanel{
	private int a;
	public MainPanel()
    {
		a= Integer.parseInt(JOptionPane.showInputDialog("Please enter the number of circles:"));//ask for numbers
    }
	public void paintComponent(Graphics m)
	{
		int x= 180;
		int y =170;
	    int r= 20;
		m.setColor(Color.black);
		for (int i=0;i<a;i++){    //use drawOval to draw the circles
			x-=20;
			y-=20;
			r+=40;
			m.drawOval(x,y,r,r);
	}
	}
}