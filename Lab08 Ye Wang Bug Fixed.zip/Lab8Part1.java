/*
 * Name: Ye Wang
 * CSC171 Lab08
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.util.Scanner;

public class Lab8Part1 {
	public static void main(String [] args){
		Scanner input= new Scanner(System.in);
		int sum,a,count;
		double avg;
		count=0;
		sum=0;
		int max=Integer.MIN_VALUE;  
		int min=Integer.MAX_VALUE;   //set the maximum value in integer type to min so that first number entered by user will always be the first min
		do{
			System.out.println("Please enter a positive integer:");
		   a= input.nextInt();
		  if(a<0)
		  	break;
		   	if (a>=max)               //if a number > current number,set that number to max
		   		max=a;
		   	if(a<=min)
		   		min=a;
		   count=count+1;
		   sum=sum+a;  
		}
		while(a>0); 
		avg=sum/(double)count;
		System.out.printf("minimun= %d \nmaximum=%d \nnumber of positive numbers=%d \nAverage=%.2f\n",min,max,count,avg);//output
        
	}
	

}
