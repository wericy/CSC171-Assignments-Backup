
/*
 * Name: Ye Wang
 * CSC171 Lab08
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.util.Scanner;
public class Lab8Part2 {
	public static void main(String [] args)
	{
		int fac,in;
		long facl;
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter a positive integer:");
		in=input.nextInt();
		fac = 1;
		facl= 1;     //set fac,facl to 1 so that the initial value won't affect the calculation of factorial
		for (int i =1;i<=in;i++)  // from 1 to the number user entered. plus one each time
		{
			fac= fac*i;    //the ascending i will multiply fac every time
		}
		for (int i =1;i<=in;i++)
		{
			facl= facl*i;
		}
	    System.out.printf("The Factorial(Integer form) of %d is %d\n",in,fac); 
	    System.out.printf("The Factorial(Long form) of %d is %d\n",in,facl);
		//the type integer will not be able to display the factorial larger than 2,147,483,647 correctly
		//however the long type can display larger number due to its extended maximum but it also unable to store factorial larger than 9,223,372,036,854,775,807
		//the result of overflow are displayed as wrong result(negative number,0...)
	    
	}
	
}
