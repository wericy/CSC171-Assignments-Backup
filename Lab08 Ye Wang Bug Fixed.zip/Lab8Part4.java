/*
 * Name: Ye Wang
 * CSC171 Lab08
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Lab8Part4 {
	public static void main(String [] args){
		MainPanel2 qp =new MainPanel2();
		JFrame frame = new JFrame();//create frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(qp);
		frame.setSize(400,400);
		frame.setVisible(true);
	}
}
class MainPanel2 extends JPanel{
	
	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		int width=getWidth();
		int height=getHeight();
		int num1=-11;
		int num2=11;
		g2.setColor(new Color(102,204,255));
		
		for (double i=0;i<=width;i=i+width/20.0)  
		    {  
			g2.setColor(new Color(102,204,255));
			g2.draw(new Line2D.Double(i,0,i,height));
			num1=num1+1;
			String s = Double.toString(num1);
			g2.setColor(Color.black); 
		    g2.drawString(s,(int)(i), height/2+height/30);
		    g2.drawString("10.0",width-width/70,height/2+height/30);
		    }		    
		for (double i=0;i<=height;i=i+height/20.0)
		{
			g2.setColor(new Color(102,204,255));
			g2.draw(new Line2D.Double(0,i,width,i));
			num2=num2-1;
			String s2= Double.toString(num2);
			g2.setColor(Color.black); 
			g2.drawString(s2,width/2+width/70,(int)(i));
			g2.drawString("10.0",width/2+width/70,height/90);
		}	
		g2.setColor(Color.black);                                                //draw axes
		g2.draw(new Line2D.Double(width/2,0,width/2,height));
		g2.draw(new Line2D.Double(0,height/2,width,height/2));
		
		g2.draw(new Line2D.Double(width/2,0,width/2+height/40,height/40));       //draw arrowhead
		g2.draw(new Line2D.Double(width/2,0,width/2-height/40,height/40));
		g2.draw(new Line2D.Double(width/2,height,width/2-height/40,height-height/40));
		g2.draw(new Line2D.Double(width/2,height,width/2+height/40,height-height/40));
		g2.draw(new Line2D.Double(0,height/2,width/40,height/2-height/40));
		g2.draw(new Line2D.Double(0,height/2,width/40,height/2+height/40));
		g2.draw(new Line2D.Double(width,height/2,width-width/40,height/2-height/40));
		g2.draw(new Line2D.Double(width,height/2,width-width/40,height/2+height/40));
		
	
 }
}


