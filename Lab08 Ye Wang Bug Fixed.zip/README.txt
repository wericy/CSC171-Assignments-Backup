Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab08

Description:
Part1:
used do...while to test if the input is >0.If so, in the loop will test if the number is larger than the current max or smaller than the current min. If so, the program will use the input value to replace the current max/min.

Part2:
fac and facl are integer type and long type. the program receives a value from the user and multiply from 1 to the given value to work out the factorial. 

Part3:
JFrame and JPanel used. Used Line2D insted of drawline to draw line with double coordinates value. For loop will plus 20 to the loop variable i,which will help to change the starting and ending point of Line2D. The arrowhead is mannually drew.

Part4:
Modified part3 used drawString,toString in the old for loop to draw the numbers on the grid. The color of the number is set to black. 

COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab8Part1
java Lab8Part2
java Lab8Part3
java Lab8Part4

FILES IN THIS LAB
--------------------------------------
Lab8Part1.java
Lab8Part2.java
Lab8Part3.java
Lab8Part4.java
README.txt
OUTPUT.txt