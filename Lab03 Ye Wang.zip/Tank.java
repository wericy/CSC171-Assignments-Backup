/*
 * Name: Ye Wang
 * CSC171 Lab03
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */

public class Tank 
{
    private String tankNation;
    private Integer yearProduced;
    public Tank(String nation,int year) 
    {
    	setTankNation(nation);
    	setyearProduced(year);    	
    }
    public void setTankNation(String nation)
    {
    	tankNation = nation;
    }
    public void setyearProduced(Integer year) 
    {
    	yearProduced = year;
	}
    public String getTankNation()
    {
    	return tankNation;
    }
    public Integer getYearProduced()
    {
		return yearProduced;    	
    }
} 
   