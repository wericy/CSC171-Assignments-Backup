/*
 * Name: Ye Wang
 * CSC171 Lab03
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
public class TestTank { 
    public static void main(String[] args){ 
    	Tank M18 =new Tank("U.S.",1943);
    	Tank t34 = new Tank("USSR",1940);
    	Tank Maus = new Tank("Germany",1944);
    	System.out.println("M18 ,"+M18. getTankNation()+","+M18.getYearProduced());  
    	System.out.println("t-34, "+t34. getTankNation()+","+t34.getYearProduced());  
    	System.out.println("Maus, "+Maus.getTankNation()+","+Maus.getYearProduced()+"\n");  
    	M18.setTankNation("U.S.A.");
    	System.out.println("M18, "+M18. getTankNation()+","+M18.getYearProduced());  
    	System.out.println("t-34, "+t34. getTankNation()+","+t34.getYearProduced());  
    	System.out.println("Maus, "+Maus. getTankNation()+","+Maus.getYearProduced());  
    	
    }

}
