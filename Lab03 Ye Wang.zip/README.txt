Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab03

Description: 
This program constructs Tank objects having the instance variables of nation and first produced year. Three inatances were created. One was modified with mutator.

COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java TestTank

FILES IN THIS LAB
--------------------------------------
TestTank.java
Tank.java
README.txt
OUTPUT.txt


