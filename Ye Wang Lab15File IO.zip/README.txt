Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab15 (2)

Description:

part1:request string. implemented with scanner the program will test if file exist. If not exist program will stop and print out "File not exist"

part2: created a array contains all characters and randomly select the array number to get a ramdom string. random numbers generated through Math.random(). BufferedWriter is used to write to file system

part3:BufferedReader is used with while loop. each time read a whole line and print out in the console.

part4:BufferedReader and PrintWriter is used in this part. When BufferedReader reads a line. the substring method will cut out the number part from the whole string . The number part is then parsed. Finally the two parts(character and number) will be output to file together.In this part, i create a temp file to store the final value. After all the output is printed,delete original file and rename the temp file with the name of original file. This will look like overwrite. 

part5:(PART 5 IS IN Lab15Part5 FILE )use showOpenDialog to show the seletion dialogbox. Then use getSelectedFile to get the file user selected. There is a try..catch block in main method to avoid program crash when user press cancel or dirctly close the dialog box. The rest part is same as Lab15.java

COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab15.java

java Lab15Part5.java

FILES IN THIS LAB
--------------------------------------
Lab15.java
Lab15Part5.java
README.txt
OUTPUT.txt