/*
 * Name: Ye Wang
 * CSC171 Lab15 (2)
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.io.*;

import javax.swing.*;
 

public class Lab15Part5 
{ 
	public static void main(String [] args) throws IOException
	{
		try{
		JFileChooser fc= new JFileChooser();  
		fc.showOpenDialog(null);//opens choose file dialog
	    File name = fc.getSelectedFile();//get selected file
		randomWrt(name);	
		trans(name);
		square(name);   // because jfilechooser won't allow choose a nonexistent file , the test process is deleted 
		}
		catch (NullPointerException e){
			System.out.println("User cancelled selection"); // avoid crash caused by user canceling the selection
		}
	}// rest part are same as Part15 file
	
	
	public static void randomWrt(File name) throws IOException  
	{
		FileWriter fw=new FileWriter(name);
		BufferedWriter bw = new BufferedWriter(fw);
		String [] randomC= {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
			
		for (int i=0;i<Math.random()*11+10;i++)
		{
			int randN=(int) (Math.random()*10)+1;
			String rand=randomC[(int) (Math.random()*25)]+randomC[(int) (Math.random()*25)]+randomC[(int) (Math.random()*25)];
			bw.write(rand+" "+randN+"\n");
		}
		bw.close();
	}
	
	
	public static void trans(File name) throws IOException
	{
		BufferedReader iS= new BufferedReader(new FileReader(name));
	    String l;
		while ((l=iS.readLine())!=null){
			System.out.println(l);		
	    }
		iS.close();
	}
	
	public static void square(File name) throws IOException//part3 squre the number
	{
		File tempa = new File("aa"); //temp file 
		BufferedReader inputStream= new BufferedReader(new FileReader(name));
		PrintWriter outputStream=new PrintWriter(new FileWriter(tempa));
		String temp;
		while((temp=inputStream.readLine())!=null)
		{
			String out=temp.substring(0,4); //cut out character part
			String out2=temp.substring(4); //cut out number part
			int og=Integer.parseInt(out2);
			int sq=(int)Math.pow(og,2); //square
			outputStream.println(out+""+sq); 
		}
		inputStream.close();
		outputStream.close();
		
		name.delete();//delete original file 	
		
		tempa.renameTo(name); //rename temp file to the name of original file
	}
}