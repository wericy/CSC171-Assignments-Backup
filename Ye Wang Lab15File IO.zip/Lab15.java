/*
 * Name: Ye Wang
 * CSC171 Lab15 (2)
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.io.*;
import java.util.Scanner;

public class Lab15 {
	public static void main (String []args) throws IOException
	{
		System.out.println("Enter the file name:");  // part1 request a string as the name of a exist file
		Scanner input= new Scanner(System.in);
		String str=input.next();
		boolean test= new File(str).isFile();//test if the file exist
		if (test== true){
		File strf= new File(str);;
		randomWrt(strf);	
     	trans(strf);
		square(strf);
		input.close();
		}
		else 
			System.out.println("File not exist");		
	}
	
	public static void randomWrt(File name) throws IOException//part2 take a file and write random characters nad numbers
	{
		FileWriter fw=new FileWriter(name);
		BufferedWriter bw = new BufferedWriter(fw);
		String [] randomC= {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
			
		for (int i=0;i<Math.random()*11+10;i++)  //random lines
		{
			int randN=(int) (Math.random()*10)+1; //random numbers from 1 to 10
			String rand=randomC[(int) (Math.random()*25)]+randomC[(int) (Math.random()*25)]+randomC[(int) (Math.random()*25)]; //token 1 , random characters
			bw.write(rand+" "+randN+"\n");
		}
		bw.close();
	}
	
	
	public static void trans(File name) throws IOException  // part3 writes file content to console
	{
		BufferedReader iS= new BufferedReader(new FileReader(name));
	    String l;
		while ((l=iS.readLine())!=null){
			System.out.println(l);		
	    }
		iS.close();
	}
	
	public static void square(File name) throws IOException//part3 squre the number
	{
		File tempa = new File("aa"); //temp file 
		BufferedReader inputStream= new BufferedReader(new FileReader(name));
		PrintWriter outputStream=new PrintWriter(new FileWriter(tempa));
		String temp;
		while((temp=inputStream.readLine())!=null)
		{
			String out=temp.substring(0,4); //cut out character part
			String out2=temp.substring(4); //cut out number part
			int og=Integer.parseInt(out2);
			int sq=(int)Math.pow(og,2); //square
			outputStream.println(out+""+sq); 
		}
		inputStream.close();
		outputStream.close();
		
		name.delete();//delete original file 	
		
		tempa.renameTo(name); //rename temp file to the name of original file
	}
	
	
	
	
	
	
	

}
