/*
 * Name: Ye Wang
 * CSC171 Lab10
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */
import java.util.Scanner;

public class lab10 
{
	public static void main (String [] args)
	{
		System.out.println("primetest(23)----"+primetest(23));//part1 test if 23 is a prime number
		System.out.println("first 100 prime numbers : ");
		prime100();//part2 test
		System.out.printf("The reverse of 13342134 is %d\n",reverse(13342134));//part3  
		System.out.println("gcd of 300 and 432----"+gcd(300,432));//part4 gcd of 300 and 432
		System.out.println("Game start====================");
		game();//part5
	}
	

	public static boolean primetest(int a)    //part1 implemented by test every possible number from 2 to the input parameter
	{
		boolean t= true; 
		if (a==1)
			t=false;
		else
		{
		for(int i=2;i<=a-1;i++)
		{
			if (a%i==0)
				t=false;
		}
	    }
		return t;
	}

	public static void prime100()   //part2  use while loop to do primetest multiple times
	{
		int i=1;
		int c=0;
		while (c<100)
		{
			if (primetest(i)==true){
				System.out.println(i);
				c++;
			}
			i++;
		}

	}

	public static int reverse(int a) //part3  
	{
		int t=a;
		int r;
		int f=0;
		for (r=0;t>0;r++)    //figure out the number of digits 
				t=t/10;   
		r--;
		for (int i=0;i<=r;i++)
		{

			f=f+(a%10)*(int)(Math.pow(10,r-i));;  //reconstruct reversed number
			a=a/10;
		}
		return f;
	}

	public static int gcd(int a, int b)  //part4  euclid alogrithm is used
	{ 
		if (a%b==0)
			return b;
		if (b%a==0)
		    return a;
	return a>=b?gcd(a,a%b):gcd(a,b%a);		
	}

	public static void game()   //part5
	{
		Scanner input= new Scanner(System.in);
		int x = (int)(Math.random()*100+1); //generate a number from 1-100
		System.out.println("Guess!");
		int a;
		int counter=0;
		do
		{
			a=input.nextInt();
			if (a>x)            // test high or low
				System.out.println("too high");
			if (a<x)
				System.out.println("too low");
			counter++;
		}
		while (a!=x);  
		System.out.printf("Correct.Congratulation! You tried %d times",counter); //final congrats

	}
}