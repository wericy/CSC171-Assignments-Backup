Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab010

Description:
part1:implemented by test every possible number from 2 to the input parameter

part2: use while loop to do primetest multiple times until find 100 prime numbers

Part3:reverse the number using mod 

Part4: euclid alogrithm is used in this method 

part5: use do while loop to request input mutiple times and use if to determine the value is high or low


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java lab10

FILES IN THIS LAB
--------------------------------------
lab10.java
README.txt
OUTPUT.txt


