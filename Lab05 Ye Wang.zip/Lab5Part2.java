/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 05
*Date: 09/29
*/

public class Lab5Part2 {
	
	public static void main(String[]args)
	{
		int a=0;
		while(a<=6)  
		{
		System.out.println("$$");	//print
		a++;    //counter 
		}
			
	}

}
