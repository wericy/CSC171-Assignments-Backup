/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 05
*Date: 09/29
*/
import java.util.Scanner;

public class Lab5Part4 {
	public static void main(String [] args){
		Scanner scan = new Scanner(System.in);
		String str,fg;
		fg= null;
		Integer sum,counter;
		counter = 0;
		sum = 0;
		double average;
		while (true){
			System.out.println("Please enter the grade in the form of A,B,C,D,E,F,N or enter Q to exit and get the average score,final grade");
			str = scan.next();
			if(str.equals("Q")) {
				average = sum/counter;
				    if (average>97)     //evaluate fianl grade 
					    fg="A+";
				    else if (average>93)
					    fg="A";
					else if (average>90)
						fg="A-";
					else if (average>87)
						fg="B+";
					else if (average>83)
						fg="B";
					else if (average>80)
						fg="B-";
					else if (average>77)
						fg="C+";
					else if (average>73)
						fg="C";
					else if (average>70)
						fg="C-";
					else if (average>67)
						fg="D+";
					else if (average>63)
						fg="D";
					else if (average>=60)
						fg="D-";
					else if (average<60)
						fg="F";
				System.out.println("Thank you. Your average score is "+ average + " and your final grade is "+ fg +"\n");
			    break;
				}
			else if (str.equals("A"))   //evaluate input
			{
				sum=sum+100;
				counter++;
			}
			else if (str.equals("B"))
			{
				sum=sum+90;
				counter++;
			}
			else if (str.equals("C"))
			{
				sum=sum+70;
				counter++;
			}
			else if (str.equals("D"))
			{
				sum=sum+60;
				counter++;
			}
			else if (str.equals("E"))
			{
				sum=sum+50;
				counter++;
			}
			else if (str.equals("F"))
			{
				sum=sum+50;
				counter++;
			}
			else if (str.equals("N"))
			{
				sum=sum+0;
				counter++;
			}
				
	}
	

}
}
