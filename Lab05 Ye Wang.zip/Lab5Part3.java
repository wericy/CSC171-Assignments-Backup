/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 05
*Date: 09/29
*/
import java.util.Scanner;

public class Lab5Part3 {
	public static void main(String [] args){
		Scanner scan = new Scanner(System.in);
		String str;
		while (true){
			System.out.println("Please enter your name or enter Q to exit");   
			str = scan.next();
			if(str.equals("Q"))      
				break;   // JUMP OUT
			else 
				System.out.println("Hi "+ str+ "\n");
					
		}
	}
	
	
}
