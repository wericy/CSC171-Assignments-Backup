Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab05

Description: 
Part1 : It's in  Lab5Part1, this program repetitively ask the user to enter pet's name. the age  and pet variables have preset value. unless the valus is changed the program will loop and ask for value.

Part2:
This program used a counter to print the $$ for  tims.

Part3:

The program ask user to enter their name or Q to exit. Used while loop with if statement. if the user enter Q, a break will stop the while loop. If user enter name, the program will say hello to user.

Part4:
Program ask user to enter their grade in the form of A,B,C,D,E,F,N or enter Q to exit and get the average score,final grade. User should enter each at one time and enter. Used if and else if to filter different grade. When enter E and F the value are both 50. The final grade do not have E because under 60 are all F. 

COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab5Part1.java

java Lab5Part2.java

java Lab5Part3.java

java Lab5Part4.java

FILES IN THIS LAB
--------------------------------------
README.txt
Lab5Part1.java
Lab5Part2.java
Lab5Part3.java
Lab5Part4.java
OUTPUT.txt