/*
*Name: Ye Wang
*Lab TA: AARON THOMPSON
*Lab Number: 05
*Date: 09/29
*/
import java.util.Scanner;
public class Lab5Part1 {                   
	public static void main(String [] args)
	{
		Scanner scan = new Scanner(System.in);
		int age = -1;
		String pet = null;
		System.out.println("Please enter your pet's name and age:");
		while(age ==-1 || pet == null)    //if not changed,loop
			if(scan.hasNextInt())
			{
				age = scan.nextInt();
				if (pet==null)
			    System.out.println("Then your pet's name?");
			}
			else
			{
				pet = scan.next();
				if (age == -1)
			    System.out.println("Then your pet's age?");}
			}
}

