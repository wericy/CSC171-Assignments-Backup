/*
 * Name: Ye Wang 
 */

import javax.swing.JOptionPane;

public class Part4 {
	public static void main(String[] args){ 
		String time= JOptionPane.showInputDialog("The number of seconds here");
		Integer c = Integer.parseInt(time);
		Integer hours = c/3600;
		Integer min = (c%3600)/60;
		Integer sec = c%3600%60;	
		String Converter=
		String.format("<html>%sseconds === <font color=#66CCFF>%shr</font> <font color=red>%smin</font> <font color=purple>%ssec</font>\n",c,hours,min,sec);
		JOptionPane.showMessageDialog(null, Converter);
		//System.out.printf("%sseconds is %shr %smin %ssec\n",c,hours,min,sec);
	}
}
