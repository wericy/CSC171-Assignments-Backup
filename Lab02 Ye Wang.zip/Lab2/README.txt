Name:Ye Wang
Class:CSC171
Lab session: Thursday 4:50-6:05
TA name: Ryan Puffer
Assignment Number:lab02

Discription:
Part1 
basic calculation on two numbers

Part2
Fahrenheit to Celsius 

Part3
Temperature unit converter with Dialogbox

Part4
A time converter. Implemented font color in dialog box by using html.

Part5
population calculator. used Long to accept big numbers.


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Part1

java Part2

java Part3

java Part4

Java Part5


FILES IN THIS LAB
--------------------------------------
Part1.java
Part2.java
Part3.java
Part4.java
Part5.java
README.txt
OUTPUT.txt
