/*
 * Name: Ye Wang 
 */
import javax.swing.JOptionPane;
public class Part3 {
	public static void main(String[] args){ 
		String celsius= JOptionPane.showInputDialog("Celsius Degree");
		double c = Double.parseDouble(celsius);
		
		double f = (c*9)/5+32;
		String Converter =
		String.format("%s Celsius Degree equals %s Fahrenheit",c,f);
		JOptionPane.showMessageDialog(null,Converter);
		
	}

}
