/*
 * Name: Ye Wang 
 */
import java.util.Scanner;

public class Part5 {
	public static void main(String[]args){
	Scanner input = new Scanner(System.in);
	System.out.println("Please enter the current population:");
	Long cp =input.nextLong();
	System.out.println();
	
	System.out.println("Please enter the current year");
	Long cy=(long) input.nextInt();
	System.out.println();
	
	System.out.println("Please enter the annual growth rate without %");
	double gp=(long) input.nextLong();
	System.out.println();
	
	System.out.println("Please enter the year you want ot estimate for");
	Long fy=(long) input.nextInt();
	System.out.println();
	
	Long futurepop = (long)(cp*(Math.pow(1+(gp/100),fy-cy)));
	System.out.println("The estimated future populatio is  "+ futurepop);
	}
}