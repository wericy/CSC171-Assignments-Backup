/*
 * Name: Ye Wang 
 */

import java.util.Scanner;

public class Part2 {
	public static void main(String[] args){ 
		Scanner scan = new Scanner(System.in);
		System.out.println("Please Enter a Fahrenheit temperature");
		String num1 = scan.next();
		
		double f = Double.parseDouble(num1);
		double c = (f-32)*5/9;
		System.out.printf("%s degrees Fahrenheit == %s degree Celsius\n",f,c);
	}
}
