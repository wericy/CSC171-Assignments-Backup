/*
 * Name: Ye Wang 
 */


import java.util.Scanner;

public class Part1 {
	public static void main(String[] args){ 
		Scanner scan = new Scanner(System.in);
		System.out.println("Please Enter two decimal numbers");
		String num1 = scan.next();
		String num2 = scan.next();
		
		double a= Double.parseDouble(num1);
		double b= Double.parseDouble(num2);
		
		double addition = a+b;
		double subtraction = a-b;
		double mutiplication =a*b;
		double division = a/b;
		
		System.out.println("a+b="+ addition);
		System.out.println("a-b="+subtraction);
		System.out.println("a*b="+mutiplication);
		System.out.println("a/b="+division);
		
	}

}
