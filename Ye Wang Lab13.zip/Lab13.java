/*  
 * Name: Ye Wang  
 * CSC171 Lab13
 * Lab TA:Aaron Thompson  
 * Lab session :TR 4:50- 6:05  
 */
public class Lab13 
{
	public static void main(String [] args)
	{
		int[][] t= randomAry(3,4);//test lab part1
		printArray(t);
    System.out.println();
		modi(t,5);
		printArray(t);
		System.out.printf("===========================\n");


    int[][] a1= randomAry(3,4); //generate random array for testing part2 and part3
    int[][] a2= randomAry(3,4);
    int[][] a3= randomAry(2,5);
    int[][] a4= randomAry(2,5);

    printArray(a1);     // test part3 
    System.out.println();
    printArray(a2);
    System.out.println();
    printArray(add(a1,a2));  
    System.out.printf("===========================\n");

    printArray(a3);     //test part4
    System.out.println();
    printArray(a4);
    System.out.println();
    printArray(diff(a3,a4));    
    System.out.printf("===========================\n");

    
    
    printArray(trig(5));    //test part4
    System.out.println();
    int[][] tt=trig(5);  
    modi(tt,3);
    printArray(tt);  
    System.out.printf("\nsum of the first two trig array :\n");
    printArray(add(trig(5),tt));// test add method 
    System.out.printf("\ndifference of the first two trig array :\n");
    printArray(diff(trig(5),tt));// test subtract method


	}


	public static int[][] randomAry(int a, int b )  //generate random array (from lab12)
    { 
        int[][] ary=new int[a][b]; 
        for(int i=0;i<ary.length;i++){ 
            for (int j=0;j<ary[i].length;j++) 
                ary[i][j]=(int) (Math.random()*(a*b+1)); 
        } 
        return ary; 
    } 


    public static void printArray(int[][] ary)    //print 2d array (from lab12)
    { 
        if (ary==null)                   // will evaluate if the input is null to avoid runtime error
          System.out.println("NULL");
        else{
        for(int i=0;i<ary.length;i++){ 
            for (int j=0;j<ary[i].length;j++) 
                System.out.print(ary[i][j]+"   "); 
            System.out.println(); 
          }
        } 
    } 




    public static void modi(int[][] ary,int a)// part1 refill the 2d array with int inputed
    {
    	for(int i=0;i<ary.length;i++){
    		for(int j=0;j<ary[i].length;j++)
    			ary[i][j]=a;
    	}
    }
    


    public static int[][] add(int[][] ary1,int [][]ary2)//part2 add two array 
    {
    	
    	boolean a=true;  
    	
    	if (ary1.length==ary2.length)
    	{
    		for (int n=0;n<ary1.length;n++)
       		  if(ary1[n].length!=ary2[n].length)
       		  a=false;
        }
      else a=false;
    	
    	
    	
        if (a==true)
        {
        	int[][] ary3=new int [ary1.length][];
          for (int i=0;i<ary1.length;i++)
            ary3[i]=new int[ary1[i].length];
    		for(int i=0;i<ary1.length;i++)
       		{
       	    	for(int j=0;j<ary1[i].length;j++)
       	    	ary3[i][j]=ary1[i][j]+ary2[i][j];
       	  }
    		return ary3;
    	  }
        else 
       	   return null;
      }
    
    
    public static int[][] diff(int[][] ary1,int [][]ary2)   //part3 difference of two array
    {
    	
    	boolean a=true;
    	
    	if (ary1.length==ary2.length)
    	{
    		for (int n=0;n<ary1.length;n++)
       		  if(ary1[n].length!=ary2[n].length)
       		  a=false;
        }
    	else a=false;
    	
    	
        if (a==true)
        {
          int[][] ary3=new int [ary1.length][];
          for (int i=0;i<ary1.length;i++)
            ary3[i]=new int[ary1[i].length];
    		for(int i=0;i<ary1.length;i++)
       		{
       	    	for(int j=0;j<ary1[i].length;j++)
       	    	ary3[i][j]=ary1[i][j]-ary2[i][j];
       	  }
    		return ary3;
    	}
        else 
       	   return null;
      }
    


    public static int[][] trig(int n)   // part4 triangular array
    {
      n++;
      int counter=1;
      int[][] a=new int [n][];
      for (int i=0;i<a.length;i++)
      {
        a[i]=new int[i];
        for (int j=0;j<a[i].length;j++)
          a[i][j]=counter++;
      }
      return a;
    }
    
    
    
    
    
    }


