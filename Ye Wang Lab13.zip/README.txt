Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab013

Description:
Part1: common nested for loop used to modify all elements to the designated int


Part2:two section used in this part. First test if two 2d arrays have same colums and rows, same-->add each element together and return array:ary3, not same-->return null

Part3:two section used in this part. First test if two 2d arrays have same colums and rows, same-->subtract two arrays (array1-array2)and  return array:ary3, not same-->return null

Part4:use int[][] a=new int [n][] leave the second length blank and use for loop to give each line different length . a counter is used to give a +1 number to next position in the triangular 2d array.

Note: The add and subtract method is once modified to accommodate the triangular array. Because the length of rows will change, there is also for loops to help create the sum and difference arraies properly.


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab13

FILES IN THIS LAB
--------------------------------------
Lab13.java
README.txt
OUTPUT.txt


