Name:Ye Wang
Class:CSC171
Lab session: Tuesday 4:50-6:05
TA name: Aaron Thompson
Assignment Number:lab04

Description: 
This program asks the user to input their name or age. If the user enters a name, the program will test whether the name is same as the programmer's name or the name of of TA. If the user enters a age, the program will give a evaluation on that age.


COMPILE INSTRCTIONS
--------------------------------------
javac *.java

RUN INSTRUCTIONS
--------------------------------------
java Lab4

FILES IN THIS LAB
--------------------------------------
README.txt
Lab4.java
OUTPUT.txt


