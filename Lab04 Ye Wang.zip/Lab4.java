/*
 * Name: Ye Wang
 * CSC171 Lab04
 * Lab TA:Aaron Thompson
 * Lab session :TR 4:50- 6:05
 */

import java.util.Scanner;
public class Lab4
{
	public static void main(String []args)
	{
		String str="";
		Integer num=null;
		Scanner input = new Scanner(System.in);	
		System.out.println("Please input your name or your age");
		if (input.hasNextInt()) 
		{
			num = input.nextInt();
			if (num< 18)
				System.out.println("A child? Don't lie to me~~");
			else if (num>= 18 && num<=25)
				System.out.println("Gold time for every thing!");
			else
			    System.out.println("Keep yourself fresh!");	
		}
		else 
		{
			str=input.next();
			if (str.equals("Eric"))
			System.out.println("Surprise! We have the same name!");
			else			
			System.out.println("Hi " + str + ", you are "+(str.equals("Aaron")?"":"not ")+"my lab TA.");
		}
			
	}
}
